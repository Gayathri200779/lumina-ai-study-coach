export const config = { maxDuration: 60 };

const MODELS = [
  "gemini-3.5-flash-lite",
  "gemini-3.8-flash"
];

function getMessage(body) {
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { return ""; }
  }
  return body && typeof body.message === "string" ? body.message.trim() : "";
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Use POST" });
  }

  // Keep the original Vercel variable name working, while also supporting
  // conventional Gemini environment-variable names.
  const apiKey = process.env.Lumina_API_Key || process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  const message = getMessage(req.body);

  if (!apiKey) {
    return res.status(500).json({
      error: "Gemini API key is missing. Add Lumina_API_Key or GEMINI_API_KEY in Vercel Environment Variables."
    });
  }

  if (!message) return res.status(400).json({ error: "Please enter a question or study material." });
  if (message.length > 30000) return res.status(413).json({ error: "The submitted text is too long." });

  let lastError = "The AI service did not return an answer.";

  for (const model of MODELS) {
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": apiKey
          },
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: message }] }],
            generationConfig: { maxOutputTokens: 4096, temperature: 0.4 }
          }),
          signal: AbortSignal.timeout(50000)
        }
      );

      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        lastError = data?.error?.message || `Gemini request failed (${response.status}).`;
        // Retry another model for unavailable, rate-limited or server errors.
        if (![400, 401, 403].includes(response.status)) continue;
        break;
      }

      const parts = data?.candidates?.[0]?.content?.parts || [];
      const reply = parts
        .filter(part => typeof part.text === "string" && !part.thought)
        .map(part => part.text)
        .join("")
        .trim();

      if (reply) return res.status(200).json({ reply, model });
      lastError = "Gemini returned an empty answer. Please try again.";
    } catch (error) {
      lastError = error?.name === "TimeoutError"
        ? "The AI request took too long. Please try again."
        : "Could not connect to the Gemini AI service.";
    }
  }

  return res.status(502).json({ error: lastError });
}
