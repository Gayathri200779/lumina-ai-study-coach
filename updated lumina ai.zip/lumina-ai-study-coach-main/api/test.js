export default function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ success: false, error: "Use GET" });
  }

  const apiKeyConfigured = Boolean(
    process.env.Lumina_API_Key || process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY
  );

  return res.status(200).json({
    success: true,
    message: apiKeyConfigured
      ? "Lumina API route is running and a Gemini API key is configured."
      : "Lumina API route is running, but no Gemini API key is configured.",
    apiKeyConfigured
  });
}
